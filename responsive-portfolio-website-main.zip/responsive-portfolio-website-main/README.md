# responsive-portfolio-website - адаптивный одностраничный сайт-портфолио
HTML, CSS, JavaScript

## О проекте
Одностраничный сайт-визитка с валидацией полей номера телефона и email, а также с переключением языка

## Демонстрация
<p align="center">
  <img src="https://github.com/cptntotoro/responsive-portfolio-website/blob/main/demo.gif?raw=true" />
</p>

